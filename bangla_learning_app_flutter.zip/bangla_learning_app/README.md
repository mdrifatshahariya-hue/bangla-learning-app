# আমার শিক্ষা 🇧🇩

Flutter-based Class 1-10 Bangla education app MVP.

## Run
1. Install Flutter.
2. Run `flutter pub get`
3. Run `flutter run`

## Build APK
`flutter build apk --release`

## Build Play Store bundle
`flutter build appbundle --release`

The current project is an MVP UI. Real NCTB book data, cartoon videos,
Firebase authentication, offline caching, progress sync and production
content should be connected next.
