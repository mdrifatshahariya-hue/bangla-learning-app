
import 'package:flutter/material.dart';

void main() => runApp(const BanglaLearningApp());

class BanglaLearningApp extends StatelessWidget {
  const BanglaLearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'আমার শিক্ষা',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7FAFF),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF078A4B)),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const LoginScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF006A3D), Color(0xFF16A05D)],
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
        ),
      ),
      child: const Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('📚', style: TextStyle(fontSize: 80)),
          SizedBox(height: 18),
          Text('আমার শিক্ষা', style: TextStyle(
            color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('শিখি • বুঝি • এগিয়ে যাই',
            style: TextStyle(color: Colors.white70, fontSize: 17)),
        ]),
      ),
    ),
  );
}

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('লগইন'), centerTitle: true),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        const SizedBox(height: 25),
        const Text('👋 স্বাগতম!', style: TextStyle(
          fontSize: 30, fontWeight: FontWeight.bold)),
        const SizedBox(height: 28),
        TextField(decoration: InputDecoration(
          labelText: 'মোবাইল / ইমেইল', prefixIcon: const Icon(Icons.person),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
        const SizedBox(height: 15),
        TextField(obscureText: true, decoration: InputDecoration(
          labelText: 'পাসওয়ার্ড', prefixIcon: const Icon(Icons.lock),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
        const SizedBox(height: 22),
        SizedBox(width: double.infinity, height: 55,
          child: ElevatedButton(
            onPressed: () => Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => const HomeScreen())),
            child: const Text('লগইন করুন', style: TextStyle(fontSize: 19)),
          )),
        TextButton(onPressed: () {}, child: const Text('নতুন অ্যাকাউন্ট তৈরি করুন')),
      ]),
    ),
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  final classes = const [1,2,3,4,5,6,7,8,9,10];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('আমার শিক্ষা 🇧🇩',
        style: TextStyle(fontWeight: FontWeight.bold)),
      actions: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.settings_outlined))
      ],
    ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: double.infinity, padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF00A859), Color(0xFF087D48)]),
            borderRadius: BorderRadius.circular(24)),
          child: const Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('হ্যালো শিক্ষার্থী! 👋', style: TextStyle(
                color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 7),
              Text('আজ কী শিখবে?', style: TextStyle(color: Colors.white, fontSize: 17)),
            ])),
            Text('🧑‍🎓', style: TextStyle(fontSize: 55)),
          ]),
        ),
        const SizedBox(height: 24),
        const Text('তোমার শ্রেণি নির্বাচন করো',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        GridView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          itemCount: classes.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14,
            childAspectRatio: 1.35),
          itemBuilder: (context, i) {
            final c = classes[i];
            return InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () {
                if (c >= 9) {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const GroupScreen()));
                } else {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => SubjectScreen(classNumber: c)));
                }
              },
              child: Card(
                elevation: 1,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(c >= 9 ? '🎓' : '📖', style: const TextStyle(fontSize: 38)),
                  const SizedBox(height: 7),
                  Text('ক্লাস $c', style: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.bold)),
                ]),
              ),
            );
          },
        ),
        const SizedBox(height: 24),
        const Text('আমার অগ্রগতি 📊',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const LinearProgressIndicator(value: .45, minHeight: 12),
        const SizedBox(height: 7),
        const Text('৪৫% সম্পন্ন', style: TextStyle(fontSize: 16)),
      ]),
    ),
    bottomNavigationBar: const NavigationBar(
      selectedIndex: 0,
      destinations: [
        NavigationDestination(icon: Icon(Icons.home), label: 'হোম'),
        NavigationDestination(icon: Icon(Icons.bar_chart), label: 'অগ্রগতি'),
        NavigationDestination(icon: Icon(Icons.person), label: 'প্রোফাইল'),
      ],
    ),
  );
}

class GroupScreen extends StatelessWidget {
  const GroupScreen({super.key});
  final groups = const [('বিজ্ঞান','🔬'),('মানবিক','🌎'),('ব্যবসায় শিক্ষা','💼')];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('গ্রুপ নির্বাচন')),
    body: ListView.builder(
      padding: const EdgeInsets.all(16), itemCount: groups.length,
      itemBuilder: (context, i) => Card(
        margin: const EdgeInsets.only(bottom: 14),
        child: ListTile(
          contentPadding: const EdgeInsets.all(14),
          leading: Text(groups[i].$2, style: const TextStyle(fontSize: 40)),
          title: Text(groups[i].$1, style: const TextStyle(
            fontSize: 20, fontWeight: FontWeight.bold)),
          trailing: const Icon(Icons.arrow_forward_ios),
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => const SubjectScreen(classNumber: 9))),
        ),
      ),
    ),
  );
}

class SubjectScreen extends StatelessWidget {
  final int classNumber;
  const SubjectScreen({super.key, required this.classNumber});
  final subjects = const [
    ('বাংলা','📕'),('ইংরেজি','📘'),('বিজ্ঞান','🔬'),
    ('বাংলাদেশ ও বিশ্বপরিচয়','🌎'),('তথ্য ও যোগাযোগ প্রযুক্তি','💻')
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('ক্লাস $classNumber')),
    body: ListView.builder(
      padding: const EdgeInsets.all(16), itemCount: subjects.length,
      itemBuilder: (context, i) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: ListTile(
          contentPadding: const EdgeInsets.all(14),
          leading: Text(subjects[i].$2, style: const TextStyle(fontSize: 38)),
          title: Text(subjects[i].$1, style: const TextStyle(
            fontSize: 19, fontWeight: FontWeight.bold)),
          trailing: const Icon(Icons.arrow_forward_ios),
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => const BookScreen())),
        ),
      ),
    ),
  );
}

class BookScreen extends StatelessWidget {
  const BookScreen({super.key});
  final chapters = const [
    'অধ্যায় ১ — পরিচয়','অধ্যায় ২ — আমাদের পরিবেশ',
    'অধ্যায় ৩ — বাংলাদেশের প্রকৃতি','অধ্যায় ৪ — মানুষের জীবন',
    'অধ্যায় ৫ — আমাদের সমাজ'
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('অধ্যায়')),
    body: ListView.builder(
      padding: const EdgeInsets.all(16), itemCount: chapters.length,
      itemBuilder: (context, i) => Card(
        child: ListTile(
          leading: CircleAvatar(child: Text('${i+1}')),
          title: Text(chapters[i], style: const TextStyle(
            fontSize: 18, fontWeight: FontWeight.w600)),
          trailing: const Icon(Icons.arrow_forward_ios),
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => const TopicScreen())),
        ),
      ),
    ),
  );
}

class TopicScreen extends StatelessWidget {
  const TopicScreen({super.key});
  final topics = const [
    ('আমাদের পরিচয়','🧑‍🎓'),('পরিবার ও সমাজ','👨‍👩‍👧‍👦'),
    ('আমাদের দেশ','🇧🇩'),('প্রকৃতি ও পরিবেশ','🌳')
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Topic')),
    body: GridView.builder(
      padding: const EdgeInsets.all(16), itemCount: topics.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14,
        childAspectRatio: .9),
      itemBuilder: (context, i) => InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => const LessonScreen())),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(topics[i].$2, style: const TextStyle(fontSize: 55)),
            const SizedBox(height: 10),
            Padding(padding: const EdgeInsets.all(8),
              child: Text(topics[i].$1, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
          ]),
        ),
      ),
    ),
  );
}

class LessonScreen extends StatelessWidget {
  const LessonScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('🎬 কার্টুন পাঠ')),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          height: 210, width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.black87, borderRadius: BorderRadius.circular(20)),
          child: const Center(child: Icon(Icons.play_circle_fill,
            color: Colors.white, size: 75)),
        ),
        const SizedBox(height: 18),
        const Text('আমাদের পরিচয়', style: TextStyle(
          fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text(
          'এই পাঠে আমরা আমাদের পরিচয়, পরিবার এবং সমাজ সম্পর্কে সহজভাবে শিখব। '
          'কার্টুন ও উদাহরণের মাধ্যমে বিষয়গুলো বোঝানো হবে।',
          style: TextStyle(fontSize: 18, height: 1.6)),
        const SizedBox(height: 24),
        SizedBox(width: double.infinity, height: 55,
          child: ElevatedButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => const QuizScreen())),
            icon: const Icon(Icons.quiz),
            label: const Text('Quiz শুরু করো', style: TextStyle(fontSize: 18)),
          )),
      ]),
    ),
  );
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});
  @override State<QuizScreen> createState() => _QuizScreenState();
}
class _QuizScreenState extends State<QuizScreen> {
  int selected = -1;
  final answers = ['পরিবার','বিদ্যালয়','খেলাধুলা','রাস্তা'];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('❓ Topic Quiz')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('প্রশ্ন ১', style: TextStyle(
          fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        const Text('একজন শিশুর সবচেয়ে কাছের সামাজিক প্রতিষ্ঠান কোনটি?',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 22),
        ...List.generate(answers.length, (i) => Container(
          width: double.infinity, margin: const EdgeInsets.only(bottom: 10),
          child: OutlinedButton(
            onPressed: () => setState(() => selected = i),
            child: Align(alignment: Alignment.centerLeft,
              child: Text('${i+1}. ${answers[i]}',
                style: const TextStyle(fontSize: 18))),
          ),
        )),
        const Spacer(),
        SizedBox(width: double.infinity, height: 55,
          child: ElevatedButton(
            onPressed: selected < 0 ? null : () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const ResultScreen())),
            child: const Text('উত্তর জমা দাও', style: TextStyle(fontSize: 18)),
          )),
      ]),
    ),
  );
}

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('🏆', style: TextStyle(fontSize: 90)),
          const SizedBox(height: 15),
          const Text('দারুণ হয়েছে!', style: TextStyle(
            fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('তোমার স্কোর', style: TextStyle(fontSize: 20)),
          const Text('৮০%', style: TextStyle(
            fontSize: 48, fontWeight: FontWeight.bold)),
          const SizedBox(height: 25),
          SizedBox(width: double.infinity, height: 55,
            child: ElevatedButton(
              onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
              child: const Text('আবার শেখা শুরু করি',
                style: TextStyle(fontSize: 18)),
            )),
        ]),
      ),
    ),
  );
}
